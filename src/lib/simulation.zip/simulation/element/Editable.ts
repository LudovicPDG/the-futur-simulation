import Proof from './Proof';

export default abstract class Editable {
	constructor(
		private argument: Set<Proof>,
		private conter_argument: Set<Proof>
	) {}

	add_argument(proof: Proof) {
		this.argument.add(proof);

        // on modifie la valeur dans la classe parente qui est marqué dans ValueToEdit.
	}
}
