import Relation from './Relation';
import Proof from './Proof';
import { neo4j_driver } from '$lib/server/utils/database';

export default class Hypothesis<T> {
	private ID: string;

	private constructor(
		private name: string,
		private description: string,
		private value: T,
		private confidence: number,
		private proofs: Set<Proof>,
		private influences: Set<Relation>,
		private influenced_by: Set<Relation>
	) {
		this.ID = crypto.randomUUID();
	}

	static async create<T>(
		name: string,
		description: string,
		value: T,
		confidence: number,
		proofs: Set<Proof>,
		influences: Set<Relation>,
		influenced_by: Set<Relation>
	) {
		const hypothesis = new Hypothesis(
			name,
			description,
			value,
			confidence,
			proofs,
			influences,
			influenced_by
		);

		const session = neo4j_driver.session();

		try {
			await session.run(
				`
				CREATE (h:Hypothesis {
					id: $id,
					name: $name,
					description: $description,
					value: $value,
					confidence: $confidence
				})
				`,
				{
					id: hypothesis.ID,
					name,
					description,
					value,
					confidence
				}
			);
			/*
			TODO: créer les realation avec
			proofs: Set<Proof>,
		influences: Set<Relation>,
		influenced_by: Set<Relation>
			*/

			// Create relation with strength hypothesis
			await session.run(
				`
				MATCH (r:Relation {id: $relationId}), (sh:Hypothesis {id: $strengthId})
				CREATE (r)-[:HAS_STRENGTH]->(sh)
				`,
				{
					relationId: relation.ID,
					strengthId: strength.getID()
				}
			);
		} finally {
			await session.close();
		}

		return hypothesis;
	}
}
